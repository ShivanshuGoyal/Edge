<div id="templatemo_footer">

Designed by : Deepak Kumar Gupta</a> | 
CSS Template from <a href="http://www.templatemo.com">Free CSS Template</a> 

</div> <!-- end of templatemo_footer -->

<div class="cleaner"></div>
