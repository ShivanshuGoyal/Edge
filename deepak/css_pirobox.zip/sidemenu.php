<div id="templatemo_menu">
	<ul>
		<li><a href="index.php" <?php if($pagename=='index.php') echo 'class="current"'; ?> >Home</a></li>
		<li><a href="academics.php" <?php if($pagename=='academics.php') echo 'class="current"'; ?> >Academics</a></li>
		<li><a href="previousworks.php" <?php if($pagename=='previousworks.php') echo 'class="current"'; ?> >Previous Works</a></li>
		<li><a href="publications.php" <?php if($pagename=='publications.php') echo 'class="current"'; ?> >Publications</a></li>
		<li><a href="achievements.php" <?php if($pagename=='achievements.php') echo 'class="current"'; ?> >Achievements</a></li>
		<li><a href="gallery.php" <?php if($pagename=='gallery.php') echo 'class="current"'; ?> >Gallery</a></li>
		<li><a href="store.php" <?php if($pagename=='store.php') echo 'class="current"'; ?> >My Store</a></li>
		<li><a href="contact.php" <?php if($pagename=='contact.php') echo 'class="current"'; ?> >Contact Me</a></li>
	</ul>
</div>
