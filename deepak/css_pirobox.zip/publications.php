﻿<?php
global $pagename, $title;
$pagename='contact.php';
$title='My Publications'; 
include('header.php');
?>
<body>


<div id="templatemo_wrapper">

	<div id="templatemo_header">
        <div id="site_title">

        </div> 
    </div> <!-- end of templatemo_header -->
    
    <div id="templatemo_main">
    
    	<?php
    	include('sidebar.php');
	include('sidebar2.php');
    	?>
        
        <div id="templatemo_content" style="margin-top:-30px">

	<h2> My Publications</h2></br></br></br>
	<h4>Journals</h4>
	• <b>Gupta, D. K.</b>, J. P. Gupta and U. Shankar, Recursive Ant Colony Optimization: A new Technique for Estimation of Function Parameters from Geophysical Data: Near Surface Geophysics (submitted after minor revision)</br></br>
	• Arora, Y., <b>D. K. Gupta</b> and U. K. Singh, SpRes 1.0: a MATLAB based GUI Application using PSO Algorithm for Inversion of Self-Potential Anomalies and 1D VES Data: Computers & Geosciences (submitted after revision)</br></br>
	• <b>Gupta, D. K.</b>, D. Bhowmick, U. Shankar and K. Sain, A velocity-porosity transform for hydrate bearing sediments: Marine Geophysical Researches (under revision). </br></br>
	• Shankar, U., <b>D. K. Gupta</b>, D. Bhowmick and K. Sain, Estimation of Gas Hydrate and free gas saturations using rock physics modelling approaches in the Krishna Godavari Basin, India: Journal of Petroleum Science and  Engineering (under peer review).</br>
</br>
	
		
	</br>
	</br>
	</br>
	</br>  
    
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
    <?php
    include('footer.php');
    ?>
</div> 
</body>
</html>
