﻿<?php
global $pagename, $title;
$pagename='contact.php';
$title='Contact Deepak'; 
include('header.php');
?>
<body>


<div id="templatemo_wrapper">

	<div id="templatemo_header">
        <div id="site_title">

        </div> 
    </div> <!-- end of templatemo_header -->
    
    <div id="templatemo_main">
    
    	<?php
    	include('sidebar.php');
	include('sidebar2.php');
    	?>
        
        <div id="templatemo_content" style="margin-top:-30px">

	<h2> Contact me at:</h2></br></br></br>
	<table border="0">
	<td width="60%">
	<h4>Current Address</h4>
	A#220, Jasper Hostel</br>
	Indian School of Mines</br>
	Mob: +91-9546482177</br>
	Alternate: +91-8987419142</br>	
	Email: me@deepakgupta.net.in</br>
        Alternate: deepauck@gmail.com</br></br>
        Skype id: deepauck</br>
	Gtalk id: deepauck</br>
	
		
	</br>
	</br>
	</br>
	</br>

	</td>			
        </table>    
    
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
	</br>
    <?php
    include('footer.php');
    ?>
</div> 
</body>
</html>
