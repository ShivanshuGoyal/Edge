           	
<h5>EAGE ISM Updates</h5>

<marquee behavior="scroll" direction="up" scrollamount="6">
		<p><a href="#" style="text-decoration:none">Vishal, Arnab and Debanjan get chance to attend the 74th EAGE Annual Conference & Exhibition</a></p>
		<p><a href="#" style="text-decoration:none">EAGE ISM Student Chapter's office bearers elected for the 2012-13 annual term</a></p>
		<p><a href="#" style="text-decoration:none">Debjani and Yogesh delivered oral presentations at the EAGE 2012 Saint Petersberg Conference</a></p>
		<p><a href="#" style="text-decoration:none">ISM students presented oral papers and posters at the SPG 2012 Conference, Hyderabad</a></p>
</marquee>