﻿<?php
global $pagename, $title;
$pagename='index.php';
$title='Deepak-zone'; 
include('header.php');
?>
<body>
	



<div id="templatemo_wrapper">

	<div id="templatemo_header">
        <div id="site_title">

        </div> 
    </div> <!-- end of templatemo_header -->
    
    <div id="templatemo_main">
    
    	<?php
    	include('sidebar.php');
	include('sidebar2.php');
    	?>
        
        <div id="templatemo_content" style="margin-top:-30px">
	<marquee behavior="scroll" direction="left"><a href="http://www.eage.org/?evp=6099&newsId=134" style="text-decoration:none">Second International Conference Geobaikal 2012 (20-24 August 2012, Irkutsk, lake Baikal, Russia). Call for papers deadline is 1 June 2012........</a>
						    <a href="http://www.eage.org/?evp=6099&newsId=127" style="text-decoration:none">International COnference on IT for Geosciences 2012 (20-24 August 2012, Dubna, Russia): Call for Papers dealine-June 1, 2012.......</marquee>
		<table width="400" border="0">
		<td width="70%"> 
          		<img src="images/2012-8-16/img1.jpg" />

		</td>	
		<td width="30%">
		
		</td>
		</table>	
	
         
          <div class="cleaner_h40"></div>
          <p>Welcome to my homepage. </p>
            
            <div class="two_column float_l">
            
              <h2>Lorem ipsum dolor </h2>
              <p>Nam porta mauris nec odio sollicitudin sodales. Quisque cursus urna in nulla commodo luctus. Nunc mi neque, imperdiet sed interdum eu.</p>
                
                <ul class="templatemo_list">
                    <li>Morbi sed nulla ac est cursus</li>
                    <li>Curabitur ullamcorper nibh nisi</li>
                    <li>Pellentesque adipiscing sollicitudin</li>
                    <li>Cras rutrum ullamcorper metus</li>
                    <li>Sed nec eros egestas nisl tincidunt</li>
                </ul>
            
          </div>
            
            <div class="two_column float_r">
            
           	  <h2>Sed nec eros egestas</h2>
              <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus, a vulputate mauris.</p>
                
                <ul class="templatemo_list">
                    <li>Pellentesque adipiscing sollicitudin</li>
                    <li>Cras rutrum ullamcorper metus</li>
                    <li>Sed nec eros egestas nisl tincidunt</li>
                    <li>Morbi sed nulla ac est cursus suscipit</li>
                    <li>Curabitur ullamcorper nibh nisi</li>
                </ul>
            
            </div>
        
      </div> 
    
    	<div class="cleaner"></div>
    </div> 
    
    <?php
    include('footer.php');
    ?>
</div> 
</body>
</html>
