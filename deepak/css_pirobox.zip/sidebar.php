<div id="templatemo_sidebar">
        
	<?php
	include('sidemenu.php');
	?>


 


</div>
