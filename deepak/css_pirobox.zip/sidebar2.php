<div id="templatemo_sidebar2" style="margin-top:-50px">
 <img src = "images/deepak-cover11.png" align="left"/> <?php
	include('newsupdates.php');
	?>


 <?php
	include('sponsors.php');
	?></div>
