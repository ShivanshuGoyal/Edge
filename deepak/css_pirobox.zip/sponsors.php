           	
<h5>Sponsors</h5>
<marquee behavior="scroll" direction="left" scrollamount="6">
		<table border="0" bgcolor="#FFFFFF">
		<td>
			<p><a href="www.eage.org" style="text-decoration:none"><image src="images/sponsors/eage.jpg"></a></p>
		</td>	
		<td>
			<p><a href="www.slb.com" style="text-decoration:none"><image src="images/sponsors/schlumberger.jpg"></a></p>
		</td>
		<td>
			<p><a href="www.cairnenergy.com" style="text-decoration:none"><image src="images/sponsors/cairn.jpg"></a></p>
		</td>
		</table>
</marquee>
